<?php
/*session_start();
 if(!isset($_SESSION['pass']))
 {
 	header("location:index.php") ;
 }
  $date1 = new DateTime("2018-03-31");
  $date2 = new DateTime();
  $diff = $date2->diff($date1)->format("%a");
  $numberofdays=$diff;*/
  include 'include/datamysql.php';

if(isset($_REQUEST['save']))
  {
  	$id=$_REQUEST['id'];
    echo $postatus=$_POST['postatus'];   
    echo $checkpostatus= $_POST['check[]'];      
    $query="UPDATE po_details SET postatus=$checkpostatus where id='$id'";
       if ($query) {
        for($count = 0; $count<count($_POST['postatus']); $count++)
        {
          $sql =mysqli_query($con,"UPDATE  po_master SET status='1' where postatus='{$_POST['postatus'][$count]}'");
        }
        if ($sql) {
                echo "<script>Swal.fire('Purchase Order Saved!','Your data has been successfully Added And Updated!','success')</script>";

        }else{
          echo "<script>alert('Please Try Again !!')</script>";
        }
}else{
echo"<script>alert('Please Try Again !!')</script>";
}
?>

<script>
//	window.location='view_po_register.php';
</script>
<?php } ?>

<?php 
	$id=$_REQUEST['id'];
	$a=mysqli_query($con,"SELECT date_format(pom.podate,'%d-%m-%Y') as podate, pod.id,pm.vendorname,bm.branchname,mm.itemname,pod.ponumber,pod.plantid, pod.creditdays,pod.discount, pod.product_id, pod.quantity,pod.rate,pod.assrate,pod.basic,pod.gstrate,pod.customerid,dm.name,pod.postatus,
  pom.price_basis,pom.delivery_schedule,pom.insurance,pom.cgst_details,pom.sgst_details,pom.igst_details,pom.freight_details,pom.delivery_place
,pom.contact_person,pom.payment_terms,pom.packing_details,pom.special_instructuions,mm.itemcode
    FROM po_details pod left join partymaster pm on pm.id=pod.customerid left join branchmaster bm on bm.branchid=pod.plantid left join itemmaster mm on pod.product_id=mm.id left join department dm on dm.id=pod.departmentid left join po_master pom on pom.ponumber=pod.ponumber where pod.ponumber='$id'");
	$y=mysqli_fetch_assoc($a);
?>

<?php include "head.php" ?>
    <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
<?php //include "header2.php" ;
    //include "sidebar.php" ;
?>
  <!-- Left side column. contains the logo and sidebar -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><b>Edit Purchase Order</b></h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                  <div class="col-md-12 col-md-offset-0">
               <div class="box box-success">
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
              <div class="box-body">
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
<!-----------Machine Master Master Entry --->
<form action="" method="post">
<div class="table-responsive"> 
<table class="table table-bordered">
<input type="hidden" value="<?php echo $y['id'] ?>" name="id"  >
<tr>
  <td>PO No. </td> <td> <input type="text" class="form-control" disabled placeholder="Order No" maxlength="100" name="ponumber" value= " <?php echo $y['ponumber'] ?>" required/> </td>

  <td>Date </td> <td><input type="text" class="form-control" placeholder ="dd/mm/yyyy" maxlength="100" readonly name="podate" style="text-transform:capitalize" value= "<?php echo $y['podate'] ?>" /> </td>

  <td>Department </td> <td> <input type="text" class="form-control" disabled placeholder="Order No" maxlength="100" name="departname" style="text-transform:capitalize" value= " <?php echo $y['name'] ?>" maxlength="100" required/> </td>
</tr>

        <tr><td>Customer Name </td> <td> 
              <?php
                $pm=mysqli_query($con,"select * from partymaster"); ?>
                <select name='customerid' style="width:600px ;" class="form-control" disabled>
                <option value=''>Customer Name </option>
          <?php 
            while($xu=mysqli_fetch_assoc($pm))
            {?>
            <option <?php if($xu['id']==$y['customerid']){echo 'selected' ;} ?> value="<?php  echo $xu['id'] ?>"><?php echo $xu['vendorname']; ?></option>;
            <?php }
            echo "</select>";
           ?>
        </td> 
      </tr>

    <div class="table-responsive">
     <table class="table table-striped table-bordered" id="user_data">
      <tr class="success">
       <th width="100px">Sr</th>  
       <th width="600px">Product id</th>
       <th width="800px">Particulars</th>
       <th width="200px">Rate</th>
       <th width="150px">Discount (%)</th>
       <th width="150px">GST (%)</th>
       <th width="200px">Quantity</th>
       <th width="200px">Basic</th>
       <th width="200px">Status</th>
       <th width="200px" align="right"><input type="checkbox" id="checkAll">All</th>
      </tr>
<!--      </table>
    </div>
    <table table class="table table-striped table-bordered" id="user_data">
 -->
      <?php
  $a=mysqli_query($con,"SELECT date_format(pom.podate,'%d-%m-%Y') as podate, pod.id,pm.vendorname,bm.branchname,mm.itemname,pod.ponumber,pod.plantid, pod.creditdays,pod.discount, pod.product_id, pod.quantity,pod.rate,pod.assrate,pod.basic,pod.gstrate,pod.customerid,dm.name,pod.postatus,
  pom.price_basis,pom.delivery_schedule,pom.insurance,pom.cgst_details,pom.sgst_details,pom.igst_details,pom.freight_details,pom.delivery_place
,pom.contact_person,pom.payment_terms,pom.packing_details,pom.special_instructuions,mm.itemcode
    FROM po_details pod left join partymaster pm on pm.id=pod.customerid left join branchmaster bm on bm.branchid=pod.plantid left join itemmaster mm on pod.product_id=mm.id left join department dm on dm.id=pod.departmentid left join po_master pom on pom.ponumber=pod.ponumber where pod.ponumber='$id'");
  /*$y=mysqli_fetch_assoc($a) ;      */
      $sr=1;
       while($y=mysqli_fetch_assoc($a)){ ?>
        <tr>
            <td style="text-align:left;  width: 100px;"><?php echo $sr; ?></td>
            <td style="text-align:left;  width: 600px;"><?php echo $y['itemcode']; ?></td>
            <td style="text-align:left;  width: 800px;"><?php echo $y['itemname']; ?></td>
            <td style="text-align:right; width: 200px;"><?php echo $y['rate']; ?></td>
            <td style="text-align:right; width: 200px;" ><?php echo $y['discount']; ?></td>
            <td style="text-align:right; width: 200px;"><?php echo $y['gstrate']; ?></td>
            <td style="text-align:right; width: 200px;"><?php echo $y['quantity']; ?></td>
            <td style="text-align:right; width: 200px;"><?php echo $y['basic']; ?></td>
            <td> <select name='postatus' class="form-control"  required><option>Regular</option> <option>Terminate</option>" </select> </td>
            <td align="center"><input type="checkbox" id="checkItem" name="check[]" value="<?php echo $y["postatus"]; ?>"></td>
            </tr>
          <?php 
          $sr++ ;}
          ?>
    </tr>
  </select>    
    <div class="table-responsive">
    <table class="table table-striped table-bordered">
    <th class="danger"> 
    Purchase Order Terms & Conditions 
    </th>  
<?php 
  $a=mysqli_query($con,"SELECT date_format(pom.podate,'%d-%m-%Y') as podate, pod.id,pm.vendorname,bm.branchname,mm.itemname,pod.ponumber,pod.plantid, pod.creditdays,pod.discount, pod.product_id, pod.quantity,pod.rate,pod.assrate,pod.basic,pod.gstrate,pod.customerid,dm.name,pod.postatus,
  pom.price_basis,pom.delivery_schedule,pom.insurance,pom.cgst_details,pom.sgst_details,pom.igst_details,pom.freight_details,pom.delivery_place
,pom.contact_person,pom.payment_terms,pom.packing_details,pom.special_instructuions FROM po_details pod left join partymaster pm on pm.id=pod.customerid left join branchmaster bm on bm.branchid=pod.plantid left join itemmaster mm on pod.product_id=mm.id left join department dm on dm.id=pod.departmentid left join po_master pom on pom.ponumber=pod.ponumber where pod.ponumber='$id'");
  $y=mysqli_fetch_assoc($a); ?>

    <tr><td>Price Basis</td>
    <td><input type="text" class="form-control"   style="width: 150px; text-align:left" name="price_basis" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['price_basis'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="price_basis"/></td>

    <td>Delivery Schedule</td>
    <td><input type="text" class="form-control" style="width: 200px;text-align:left" name="delivery_schedule" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['delivery_schedule'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="delivery_schedule"/></td>

    <td>Insurance</td>
    <td><input type="text" class="form-control" style="width: 200px;text-align:left" name="insurance" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['insurance'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="insurance"/></td>

    <td>CGST Details</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="cgst_details" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['cgst_details'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="cgst_details"/></td></tr>

    <tr><td>SGST Details</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="sgst_details" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['sgst_details'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="sgst_details"/></td>

    <td>IGST Details</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="igst_details" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['igst_details'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="igst_details"/></td>

    <td>Freight Details</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="freight_details" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['freight_details'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="freight_details"/></td>

    <td>Delivery Place</td>
    <td><input type="text" class="form-control" style="width: 200px;text-align:left" name="delivery_place" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['delivery_place'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="delivery_place"/></td></tr>

    <tr><td>Contact Person</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="contact_person" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['contact_person'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="contact_person"/></td>

    <td>Payment Terms</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="payment_terms" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['payment_terms'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="payment_terms"/></td>

    <td>Packing Details</td>
    <td><input type="text" class="form-control"  style="width: 200px;text-align:left" name="packing_details" onblur="if(this.value=='')this.value=this.defaultValue;" value="<?php echo $y['packing_details'];?>" onfocus="if(this.value==this.defaultValue)this.value='';" required id="packing_details"/></td>
    
    <td>Special Instructions</td>
    <td><input type="text" class="form-control" value="<?php echo $y['special_instructuions'];?>"  style="width: 200px;text-align:left" name="special_instructuions" onblur="if(this.</td>value=='')this.value=this.defaultValue;" onfocus="if(this.value==this.defaultValue)this.value='';" required id="special_instructuions"/></td></tr>
<tr>
<td><input type="submit"value="Update"name='save' class="btn btn-primary"/> <input type="reset" value="Reset"class="btn btn-primary"/>
<a href="generatepdf_po.php?id=<?php echo $y['ponumber']; ?>" target='_blank' class="btn btn-primary">PO Print</a></td> 
</td>

</tr>
</table>
</td>
</tr>
</select>
</td>
<!-- </table>
</div>
 -->
</form>
<!-----------End of Employee Master Entry --->

              </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Main row -->
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php  //include "footer.php" ; ?>
<script>
  $("#checkAll").click(function () {
  $('input:checkbox').not(this).prop('checked', this.checked);
  });
</script>
