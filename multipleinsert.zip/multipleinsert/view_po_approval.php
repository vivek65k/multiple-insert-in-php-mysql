<?php  
/*	session_start();
	 if(!isset($_SESSION['pass']))
	 {
		header("location:index.php") ;
	 }*/
	include "head.php"; 
	include 'include/datamysql.php';
	$a=mysqli_query($con,"SELECT date_format(podate,'%d-%m-%Y') as podate, pod.id,pm.vendorname,bm.branchname,mm.itemname,pod.ponumber,pod.plantid, pod.creditdays, pod.product_id, pod.quantity,pod.rate,pod.assrate,pod.basic,pod.gstrate FROM po_details pod left join partymaster pm on pm.id=pod.customerid left join branchmaster bm on bm.branchid=pod.plantid left join itemmaster mm on pod.product_id=mm.id group by ponumber");?>
    <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
<?php // include "header2.php" ;
      //include "sidebar.php" ;
?>
  <!-- Left side column. contains the logo and sidebar -->  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><b>Purchase Order Apprival</b></h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->

              <div class="box-body">
              <div class="table-responsive">  
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Sr</th>  
                <th>Order Number</th>
                <th>Date</th>
                <th>Customer Name</th>
                <th>Location </th>
                <th>Quantity</th>
                <th align="right">Basic Amount</th>
               </tr>
                </thead>
                <tbody>
               <?php 
					$sr=1;
					while($y=mysqli_fetch_assoc($a)){ ?>
						<tr>
						<td><?php echo $sr; ?></td>
            <td style="width: 200px;"><a href="edit_po_entry.php?id=<?php echo $y['ponumber']; ?>"><?php echo $y['ponumber']; ?> </a></td>
            <td><?php echo $y['podate']; ?></td>
            <td style="width: 300px;"><?php echo $y['vendorname']; ?> </a></td>
            <td><?php echo $y['branchname']; ?></td>
            <td style="text-align:right"><?php echo $y['quantity']; ?></td>
            <td style="text-align:right"><?php echo $y['basic']; ?></td>
						</tr>
					<?php 
					$sr++ ;}
					?>
                </tbody>
              </table>
            </div>
            </div>
            </div>
            </div>
          </div>
      <!-- Main row -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php //  include "footer.php" ; ?>
