<?php
$con=odbc_connect('sms1','','88788');
if (!$con)
  {exit("Connection Failed: " . $con);}
?>



