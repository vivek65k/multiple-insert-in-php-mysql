<?php
	$con=mysqli_connect("localhost","saimdevt_user","admin@9402","saimdevt_payroll");
?>



